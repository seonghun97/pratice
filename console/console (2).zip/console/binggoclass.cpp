#include<iostream>
#include<time.h>

using namespace std;

class Binggo
{
public:

private:
	int binggo = 0;
};


int main()
{
	srand(time(NULL));

	int bNumber[25] = {};

	for (int i = 0; i < 25; ++i)
	{
		bNumber[i] = i + 1;
	}

	int iTemp, idx1, idx2;
	for (int i = 0; i < 100; ++i)
	{
		idx1 = rand() % 25;
		idx2 = rand() % 25;

		iTemp = bNumber[idx1];
		bNumber[idx1] = bNumber[idx2];
		bNumber[idx2] = iTemp;
	}

	int Bingo = 0;
	while (true)
	{
		system("cls");
		for (int i = 0; i < 5; ++i)
		{
			for (int j = 0; j < 5; ++j)
			{
				if (bNumber[i * 5 + j] == INT_MAX)
				{
					cout << "*\t";
				}
				else
				{
					cout << bNumber[i * 5 + j] << "\t";
				}

			}
			cout << endl;
		}
		if (Bingo >= 3)
		{
			cout << "3���� ��������" << endl;
			break;
		}
		cout << "���� : " << Bingo << endl;
		cout << "���ڸ� �Է��ϼ��� : ";
		int iInput;
		cin >> iInput;

		if (iInput < 1 || iInput > 25)
		{
			break;
		}
		bool dup = true;

		for (int i = 0; i < 25; ++i)
		{
			if (iInput == bNumber[i])
			{
				dup = false;
				bNumber[i] = INT_MAX;

				break;

			}

		}
		
		if (dup)
			continue;

		Bingo = 0;

		int Star1 = 0, Star2 = 0;

		for (int i = 0; i < 5; ++i)
		{
			Star1 = Star2 = 0;
			for (int j = 0; j < 5; ++j)
			{
				if (bNumber[i * 5 + j] == INT_MAX)
				{
					++Star1;
				}
				if (bNumber[j * 5 + i] == INT_MAX)
				{
					++Star2;
				}
			}

			if (Star1 == 5)
				++Bingo;
			if (Star2 == 5)
				++Bingo;
		}
		Star1 = 0;
		for (int i = 0; i < 25; i += 6)
		{
			if (bNumber[i] == INT_MAX)
				++Star1;
		}
		if (Star1 == 5)
			++Bingo;
		Star1 = 0;
		for (int i = 4; i <= 20; i += 4)
		{
			if (bNumber[i] == INT_MAX)
				++Star1;
		}
		if (Star1 == 5)
			++Bingo;
	}

	return 0;


}