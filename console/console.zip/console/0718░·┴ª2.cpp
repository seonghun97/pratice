﻿#include <iostream>

using namespace std;




	void main()
{
    int num1, num2;
    int total1, total2;

    cout << "숫자 입력: " << endl;
    cin >> num1 >> num2;

    total1 = num1 + num2;
    total2 = num1 - num2;

    cout << "입력한 숫자의 덧셈 결과: " << total1 << endl;
    cout << "입력한 숫자의 뺄셈 결과: " << total2 << endl;

}
	
    //void main() 
//{
//    int num1, num2, num3;
//
//

//    cout << "세 개의 정수를 입력하세요: ";
//    cin >> num1 >> num2 >> num3;
//
//    int total = (num1 + num2) * (num3 + num1) % num1;
//    cout << "(num1 + num2) * (num3 + num1) % num1 = " << total << endl;
//
//

//}

    //void main() 
// {
//    int num1, num2;
//    int j, i;
//
//

//    cout << "정수를 입력하세요: ";
//    cin >> num1 >> num2;
//
//    j = num1 / num2;
//    i = num1 % num2;
//
//    cout << "몫은 " << j << "이고, 나머지는 " << i << "입니다." << endl;
//
//

//}




